import { generateText } from "ai"
import { gateway } from "@ai-sdk/gateway"
import { NextResponse } from "next/server"

export async function POST(request: Request) {
  try {
    const body = await request.json() as { workTitle?: string; author?: string; mode?: string; sections?: string[]; notes?: string }
    const workTitle = body.workTitle?.trim()
    if (!workTitle) return NextResponse.json({ error: "Vui lòng nhập tên tác phẩm." }, { status: 400 })

    const result = await generateText({
      model: gateway("google/gemini-3-flash"),
      system: "Bạn là Lemon, trợ lý nghiên cứu Ngữ văn bằng tiếng Việt. Viết chính xác, mạch lạc, phân biệt rõ dữ kiện với diễn giải. Nếu không chắc chi tiết tác phẩm, hãy nói rõ và không bịa trích dẫn.",
      prompt: `Hãy viết một bài phân tích văn học về tác phẩm: ${workTitle}. Tác giả: ${body.author?.trim() || "chưa rõ"}. Chế độ: ${body.mode || "Cơ bản"}. Các mục cần có: ${(body.sections || []).join(", ")}. Ghi chú của người học: ${body.notes?.trim() || "không có"}.\n\nTrình bày bằng tiếng Việt với tiêu đề, mở bài, các luận điểm có dẫn giải, nghệ thuật và kết luận. Nếu tác phẩm có nhiều dị bản hoặc thông tin chưa chắc chắn, hãy ghi chú thay vì khẳng định.`
    })

    return NextResponse.json({ content: result.text })
  } catch {
    return NextResponse.json({ error: "Lemon chưa thể tạo kết quả lúc này. Vui lòng thử lại." }, { status: 500 })
  }
}
