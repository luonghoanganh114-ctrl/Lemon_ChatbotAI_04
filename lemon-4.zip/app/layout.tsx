import type { Metadata, Viewport } from "next"
import { Be_Vietnam_Pro } from "next/font/google"
import { Analytics } from "@vercel/analytics/next"
import { BotpressWidget } from "@/components/lemon/botpress-widget"
import "./globals.css"

const beVietnamPro = Be_Vietnam_Pro({
  subsets: ["latin", "vietnamese"],
  weight: ["400", "500", "600", "700", "800"],
  display: "swap",
  variable: "--font-be-vietnam-pro",
})

export const metadata: Metadata = {
  title: {
    default: "LEMON — Nghiên cứu văn học",
    template: "%s | LEMON",
  },
  description: "Chạm vào tri thức – Khám phá chiều sâu văn học.",
  applicationName: "LEMON",
  icons: { icon: "/icon.svg" },
}

export const viewport: Viewport = {
  colorScheme: "light",
  themeColor: "#f6f8fc",
  width: "device-width",
  initialScale: 1,
}

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="vi" className={beVietnamPro.variable}>
      <body className="antialiased">
        {children}
        <BotpressWidget />
        {process.env.NODE_ENV === "production" && <Analytics />}
      </body>
    </html>
  )
}
