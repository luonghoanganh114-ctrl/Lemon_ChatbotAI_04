import type { Metadata } from "next"
import { AuthPanel } from "@/components/lemon/auth-panel"

export const metadata: Metadata = { title: "Tạo tài khoản" }

export default function RegisterPage() {
  return <AuthPanel mode="register" />
}
