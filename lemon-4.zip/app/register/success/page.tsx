import Link from "next/link"
import { CheckCircle2, Leaf } from "lucide-react"

export default function RegisterSuccessPage() {
  return (
    <main className="auth-shell">
      <div className="auth-backdrop" aria-hidden="true" />
      <section className="auth-card auth-success-card" aria-labelledby="success-title">
        <div className="auth-brand" aria-label="Lemon">
          <span className="brand-mark"><Leaf size={20} strokeWidth={2.4} /></span>
          <span>LEMON<span className="brand-dot">.</span></span>
        </div>
        <div className="success-icon" aria-hidden="true"><CheckCircle2 size={34} /></div>
        <div className="auth-heading">
          <span className="eyebrow">Đăng ký hoàn tất</span>
          <h1 id="success-title">Tài khoản đã được tạo</h1>
          <p>Không cần chờ thông báo qua email. Bạn có thể đăng nhập và bắt đầu khám phá Lemon ngay.</p>
        </div>
        <Link className="button button-primary auth-submit success-action" href="/login">Đến trang đăng nhập</Link>
        <p className="auth-footnote">Hãy dùng đúng email và mật khẩu bạn vừa đăng ký.</p>
      </section>
    </main>
  )
}
