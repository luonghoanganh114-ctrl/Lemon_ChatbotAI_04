import { notFound } from "next/navigation"
import { AccountOverview } from "@/components/lemon/account-overview"
import { AnalysisDetail } from "@/components/lemon/analysis-detail"
import { AnalysisLibrary, type SavedAnalysis } from "@/components/lemon/analysis-library"
import { ChatWorkspace } from "@/components/lemon/chat-workspace"
import { CompetencyTest } from "@/components/lemon/competency-test"
import { ConversationList } from "@/components/lemon/conversation-list"
import { DashboardView } from "@/components/lemon/dashboard-view"
import { HistoryView } from "@/components/lemon/history-view"
import { KnowledgeView } from "@/components/lemon/knowledge-view"
import { ProfileForm } from "@/components/lemon/profile-form"
import { SecurityForm, SettingsView } from "@/components/lemon/settings-views"
import { ToolWorkbench } from "@/components/lemon/tool-workbench"
import { createClient } from "@/lib/supabase/server"

const analysisColumns = "id,title,work_title,author_name,analysis_mode,tags,content,created_at,updated_at"

export default async function WorkspaceRoute({
  params,
  searchParams,
}: {
  params: Promise<{ segments: string[] }>
  searchParams: Promise<{ [key: string]: string | string[] | undefined }>
}) {
  const [{ segments }, query] = await Promise.all([params, searchParams])
  const [section, id] = segments
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) notFound()

  if (section === "dashboard") {
    const [analysisResult, conversationResult] = await Promise.all([
      supabase.from("saved_analyses").select("id,title,work_title,author_name,analysis_mode,updated_at").eq("user_id", user.id).order("updated_at", { ascending: false }).limit(20),
      supabase.from("conversations").select("id,title,updated_at").eq("user_id", user.id).order("updated_at", { ascending: false }).limit(20),
    ])
    return <DashboardView name={String(user.user_metadata?.full_name || user.email?.split("@")[0] || "nhà nghiên cứu")} analyses={analysisResult.data ?? []} conversations={conversationResult.data ?? []} />
  }

  if (section === "tools" && id === "competency-test") return <CompetencyTest />
  if (section === "tools") return <ToolWorkbench tool={id ?? "analysis"} />

  if (section === "chat") {
    const requestedId = typeof query.id === "string" ? query.id : null
    const [conversationResult] = await Promise.all([
      supabase.from("conversations").select("id,title,updated_at").eq("user_id", user.id).order("updated_at", { ascending: false }).limit(100),
    ])
    const conversation = requestedId ? (conversationResult.data ?? []).find((item) => item.id === requestedId) : null
    const messageResult = conversation
      ? await supabase.from("messages").select("id,role,content,created_at").eq("user_id", user.id).eq("conversation_id", conversation.id).order("created_at", { ascending: true }).limit(300)
      : { data: [] }
    return <ChatWorkspace initialConversations={conversationResult.data ?? []} selectedConversation={conversation?.id ?? null} initialMessages={messageResult.data ?? []} />
  }

  if (section === "my-analyses") {
    if (id) {
      const { data } = await supabase.from("saved_analyses").select(analysisColumns).eq("user_id", user.id).eq("id", id).maybeSingle()
      if (!data) notFound()
      return <AnalysisDetail analysis={data as SavedAnalysis} />
    }
    const [{ data }, { query: queryParam }] = await Promise.all([
      supabase.from("saved_analyses").select(analysisColumns).eq("user_id", user.id).order("updated_at", { ascending: false }).limit(200),
      Promise.resolve({ query: typeof query.query === "string" ? query.query : "" }),
    ])
    return <AnalysisLibrary initial={(data ?? []) as SavedAnalysis[]} initialQuery={queryParam} />
  }

  if (section === "my-conversations") {
    const { data } = await supabase.from("conversations").select("id,title,updated_at,created_at").eq("user_id", user.id).order("updated_at", { ascending: false }).limit(200)
    return <ConversationList initial={data ?? []} />
  }

  if (section === "profile") {
    const { data: profile } = await supabase.from("profiles").select("full_name,bio,interests,avatar_url,created_at").eq("id", user.id).maybeSingle()
    let avatarUrl: string | null = null
    if (profile?.avatar_url) {
      const result = await supabase.storage.from("lemon-avatars").createSignedUrl(profile.avatar_url, 60 * 15)
      avatarUrl = result.data?.signedUrl ?? null
    }
    return <div><div className="page-heading"><div><span className="page-kicker">HỒ SƠ CÁ NHÂN</span><h1>Hồ sơ của bạn</h1><p>Cập nhật thông tin hiển thị và những chủ đề bạn quan tâm.</p></div></div><ProfileForm profile={profile} email={user.email ?? ""} createdAt={user.created_at} avatarUrl={avatarUrl} /></div>
  }

  if (section === "settings") {
    if (id === "security") return <SecurityForm />
    return <SettingsView />
  }

  if (section === "library") return <KnowledgeView type="library" query={typeof query.query === "string" ? query.query : ""} />
  if (section === "authors") return <KnowledgeView type="authors" query={typeof query.query === "string" ? query.query : ""} />

  if (section === "history") {
    const [analyses, conversations] = await Promise.all([
      supabase.from("saved_analyses").select("id,title,updated_at").eq("user_id", user.id).order("updated_at", { ascending: false }).limit(100),
      supabase.from("conversations").select("id,title,updated_at").eq("user_id", user.id).order("updated_at", { ascending: false }).limit(100),
    ])
    return <HistoryView analyses={analyses.data ?? []} conversations={conversations.data ?? []} />
  }

  if (section === "account") return <AccountOverview email={user.email ?? ""} />
  notFound()
}
