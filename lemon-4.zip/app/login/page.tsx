import type { Metadata } from "next"
import { AuthPanel } from "@/components/lemon/auth-panel"

export const metadata: Metadata = { title: "Đăng nhập" }

export default function LoginPage() {
  return <AuthPanel mode="login" />
}
