import Link from "next/link"
import { ArrowDownRight, ArrowRight, BadgeCheck, BarChart3, BookOpen, BookOpenCheck, Bot, BrainCircuit, Code2, Database, FileText, GitCompareArrows, Heart, Leaf, Library, MessageCircle, MessageSquareText, Quote, Scale, Share2, Sparkles, Users, Workflow } from "lucide-react"

const features = [
  { icon: BookOpenCheck, title: "Phân tích tác phẩm", copy: "Mở rộng từng lớp chủ đề, hình tượng và nghệ thuật.", href: "/login?next=%2Ftools%2Fanalysis", tone: "yellow" },
  { icon: Users, title: "Nghiên cứu tác giả", copy: "Đặt cuộc đời sáng tác trong bối cảnh lịch sử.", href: "/login?next=%2Ftools%2Fauthor", tone: "green" },
  { icon: GitCompareArrows, title: "So sánh văn học", copy: "Nhìn thấy điểm gặp và khoảng cách giữa tác phẩm.", href: "/login?next=%2Ftools%2Fcompare", tone: "blue" },
  { icon: Scale, title: "Phản biện học thuật", copy: "Kiểm tra tiền đề, lập luận và cách diễn giải.", href: "/login?next=%2Ftools%2Fcritique", tone: "lavender" },
  { icon: BadgeCheck, title: "Kiểm chứng dẫn chứng", copy: "Tách bạch điều đã xác minh và điều còn cần nguồn.", href: "/login?next=%2Ftools%2Fverify", tone: "green" },
  { icon: Library, title: "Thư viện nghiên cứu", copy: "Lưu bài phân tích và tiếp tục từ đúng điểm dừng.", href: "/login?next=%2Fmy-analyses", tone: "yellow" },
]

export function MarketingHome() {
  return (
    <main className="landing-page">
      <header className="landing-header">
        <Link href="/" className="brand-lockup"><span className="brand-mark"><BookOpen size={20} /></span><span className="brand-word">LEMON<span className="brand-dot">.</span></span></Link>
        <nav className="landing-nav" aria-label="Điều hướng chính"><a href="#features">Khám phá</a><a href="#principles">Cách tiếp cận</a></nav>
        <div className="landing-actions"><Link href="/login" className="login-link">Đăng nhập</Link><Link href="/register" className="button button-primary button-small">Bắt đầu miễn phí <ArrowRight size={16} /></Link></div>
      </header>
      <section className="landing-hero">
        <div className="hero-copy">
          <span className="hero-eyebrow"><span className="eyebrow-dot" /> KHÔNG GIAN NGHIÊN CỨU VĂN HỌC</span>
          <h1>Văn học mở ra<br />những <span>chiều sâu</span><br />mới.</h1>
          <p className="hero-lede">Một không gian để đặt câu hỏi, kết nối ý tưởng và lưu lại hành trình đọc — với sự cẩn trọng của nghiên cứu học thuật.</p>
          <div className="hero-ctas"><Link href="/register" className="button button-primary">Tạo không gian của bạn <ArrowRight size={17} /></Link><a href="#features" className="text-link">Khám phá công cụ <ArrowDownRight size={16} /></a></div>
          <div className="hero-caption"><span className="caption-line" /><span>Chạm vào tri thức – Khám phá chiều sâu văn học.</span></div>
        </div>
        <div className="hero-art" aria-label="Minh họa không gian nghiên cứu Lemon">
          <div className="art-grid" />
          <div className="art-orbit art-orbit-one" /><div className="art-orbit art-orbit-two" />
          <div className="art-sun"><span className="sun-core"><Leaf size={46} strokeWidth={1.5} /></span><span className="sun-ray ray-one" /><span className="sun-ray ray-two" /><span className="sun-ray ray-three" /></div>
          <div className="art-note note-top"><span className="note-icon"><Quote size={16} /></span><span><strong>Một câu hỏi hay</strong><small>mở ra nhiều cách đọc</small></span></div>
          <div className="art-note note-bottom"><span className="note-icon note-blue"><Sparkles size={16} /></span><span><strong>Không gian riêng</strong><small>mọi nghiên cứu được lưu lại</small></span></div>
          <div className="art-book"><BookOpen size={42} strokeWidth={1.3} /><span>Đọc · Nghĩ · Kết nối</span></div>
          <div className="art-stamp">LEMON<br /><span>STUDY ROOM</span></div>
        </div>
      </section>
      <section className="landing-principles" id="principles">
        <div className="principle-intro"><span className="eyebrow">MỘT CÁCH ĐỌC KHÁC</span><h2>Không phải một chatbot.<br /><em>Một hệ sinh thái nghiên cứu.</em></h2></div>
        <div className="principle-item"><span className="principle-number">01</span><p>Giữ lại <strong>câu hỏi và bản nháp</strong> trong không gian cá nhân.</p></div>
        <div className="principle-item"><span className="principle-number">02</span><p>Phân biệt <strong>dữ kiện, nhận định và diễn giải</strong>.</p></div>
        <div className="principle-item"><span className="principle-number">03</span><p>Minh bạch khi <strong>nguồn dữ liệu hoặc AI chưa kết nối</strong>.</p></div>
      </section>
      <section className="landing-features" id="features">
        <div className="section-heading"><div><span className="eyebrow">BỘ CÔNG CỤ LEMON</span><h2>Mỗi ý tưởng, một lối mở.</h2></div><p>Bắt đầu từ một tác phẩm, một luận điểm hay một câu hỏi chưa có lời giải.</p></div>
        <div className="feature-grid">
          {features.map(({ icon: Icon, title, copy, href, tone }) => <Link href={href} className="feature-card" key={title}>
            <span className={`feature-icon ${tone}`}><Icon size={20} strokeWidth={1.8} /></span><span className="feature-title">{title}</span><span className="feature-copy">{copy}</span><span className="feature-arrow"><ArrowRight size={17} /></span>
          </Link>)}
        </div>
      </section>
      <section className="project-showcase" id="project">
        <div className="showcase-heading"><span className="eyebrow">HỒ SƠ DỰ ÁN</span><h2>Lemon được tạo để học sâu hơn, không chỉ trả lời nhanh hơn.</h2><p>Từ ý tưởng ban đầu đến một chatbot có ngữ cảnh, mọi lớp của sản phẩm đều được thiết kế để minh bạch và có thể trình diễn.</p></div>
        <div className="showcase-grid">
          <article className="showcase-card showcase-wide"><div className="showcase-card-head"><span className="showcase-icon yellow"><FileText size={18} /></span><span className="showcase-kicker">01 · Ý tưởng & prompt</span></div><h3>Một không gian nghiên cứu văn học có trách nhiệm</h3><p>Prompt tạo website tập trung vào trải nghiệm đọc, phân biệt dữ kiện với diễn giải và lưu lại hành trình suy nghĩ của người học.</p><div className="prompt-snippet">“Thiết kế một nền tảng nghiên cứu văn học Việt Nam, nơi AI đặt câu hỏi ngược, trích dẫn rõ nguồn và không thay thế tư duy của người đọc.”</div></article>
          <article className="showcase-card"><div className="showcase-card-head"><span className="showcase-icon blue"><Code2 size={18} /></span><span className="showcase-kicker">02 · Nền tảng</span></div><h3>Next.js · Supabase · Botpress</h3><p>Giao diện responsive, xác thực tài khoản và dữ liệu cá nhân được lưu an toàn trong workspace riêng.</p><div className="stack-pills"><span>Next.js</span><span>Supabase</span><span>Botpress</span></div></article>
          <article className="showcase-card"><div className="showcase-card-head"><span className="showcase-icon green"><BrainCircuit size={18} /></span><span className="showcase-kicker">03 · Instructions chatbot</span></div><h3>Lemon hỏi trước khi trả lời</h3><ul className="showcase-list"><li>Xác định tác phẩm và mục tiêu đọc</li><li>Tách nguồn, nhận định, diễn giải</li><li>Gợi mở phản biện thay vì viết hộ</li></ul></article>
          <article className="showcase-card showcase-wide"><div className="showcase-card-head"><span className="showcase-icon lavender"><Database size={18} /></span><span className="showcase-kicker">04 · Knowledge Base</span></div><h3>Kho tri thức có cấu trúc</h3><p>Ngữ cảnh chatbot được tổ chức theo tác phẩm, tác giả, thời kỳ và chủ đề. Mỗi câu trả lời có thể quay về đúng lớp thông tin đã dùng.</p><div className="knowledge-flow"><span>Tác phẩm</span><ArrowRight size={14} /><span>Tác giả & bối cảnh</span><ArrowRight size={14} /><span>Gợi ý đọc sâu</span></div></article>
          <article className="showcase-card intelligence-card"><div className="showcase-card-head"><span className="showcase-icon yellow"><Sparkles size={18} /></span><span className="showcase-kicker">05 · Demo mức độ thông minh</span></div><div className="chat-demo"><div className="chat-bubble user-bubble">Vì sao hình ảnh dòng sông xuất hiện nhiều trong văn học?</div><div className="chat-bubble bot-bubble"><strong>Lemon · Gợi mở 3 lớp đọc</strong><br />Biểu tượng, không gian ký ức và chuyển động của nhân vật. Bạn muốn bắt đầu từ tác phẩm nào?</div></div><button className="demo-button" type="button" aria-label="Demo chatbot Lemon"><MessageCircle size={15} /> Xem cách Lemon suy luận</button></article>
          <article className="showcase-card"><div className="showcase-card-head"><span className="showcase-icon green"><Workflow size={18} /></span><span className="showcase-kicker">06 · Automation</span></div><h3>Những việc được tự động hóa</h3><ul className="showcase-list"><li>Lưu câu hỏi và phiên phân tích</li><li>Gợi ý tiếp tục từ lịch sử đọc</li><li>Đồng bộ hồ sơ và thư viện cá nhân</li></ul></article>
        </div>
        <div className="social-proof-card"><div className="social-post"><div className="post-avatar">L</div><div className="post-copy"><strong>Lemon Study Room</strong><span>@lemon.study · 2 giờ trước</span><p>“Một câu hỏi hay mở ra nhiều cách đọc.” Hôm nay bạn đang đọc tác phẩm nào?</p><div className="post-actions"><span><Heart size={15} /> 248</span><span><MessageCircle size={15} /> 36</span><span><Share2 size={15} /> 19</span></div></div></div><div className="engagement"><BarChart3 size={18} /><strong>303</strong><span>lượt tương tác<br />trên bài đăng giới thiệu</span></div></div>
      </section>
      <section className="landing-cta"><div className="cta-mark"><Bot size={21} /></div><div><h2>Bắt đầu từ điều bạn muốn tìm hiểu.</h2><p>Không gian Lemon của bạn luôn sẵn sàng — các kết quả nghiên cứu chỉ xuất hiện khi có nguồn và kết nối thực.</p></div><Link href="/register" className="button button-dark">Tạo tài khoản <ArrowRight size={16} /></Link></section>
      <footer className="landing-footer"><span>© LEMON · Nghiên cứu văn học có trách nhiệm</span><span><MessageSquareText size={14} /> Chatbot trực tuyến ở góc màn hình</span></footer>
    </main>
  )
}
