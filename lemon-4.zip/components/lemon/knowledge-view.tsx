import Link from "next/link"
import { ArrowRight, BookOpenCheck, Database, Library, Search, Users } from "lucide-react"

export function KnowledgeView({ type, query = "" }: { type: "library" | "authors"; query?: string }) {
  const authors = type === "authors"
  const title = authors ? "Nghiên cứu tác giả" : "Thư viện văn học"
  const description = authors ? "Tra cứu hồ sơ tác giả theo thời kỳ, quốc gia và trường phái." : "Khám phá tài liệu văn học theo thời kỳ, quốc gia, thể loại và chủ đề."
  const Icon = authors ? Users : Library
  return <div>
    <div className="page-heading"><div><span className="page-kicker">KHO TRI THỨC LEMON</span><h1>{title}</h1><p>{description}</p></div><Link href={authors ? "/tools/author" : "/my-analyses"} className="button button-quiet button-small">{authors ? "Tạo ghi chú tác giả" : "Thư viện cá nhân"} <ArrowRight size={14} /></Link></div>
    <form className="card-surface" action={authors ? "/authors" : "/library"} style={{ display: "flex", gap: 10, padding: 15, marginBottom: 15 }}><label className="list-search" style={{ flex: 1 }}><Search size={16} /><input type="search" name="query" defaultValue={query} placeholder={authors ? "Tên tác giả, quốc gia hoặc trường phái" : "Tên tác phẩm, tác giả hoặc chủ đề"} aria-label={`Tìm trong ${title}`} /></label><button type="submit" className="button button-primary button-small">Tìm kiếm</button></form>
    <section className="card-surface empty-state" style={{ minHeight: 260 }}><span className="empty-state-icon"><Icon size={20} /></span><strong>{query ? `Chưa có kết quả cho “${query}”` : "Nguồn dữ liệu chưa được kết nối"}</strong><p>{authors ? "Không hiển thị tiểu sử hoặc thông tin tác giả chưa được xác minh. Kết nối bộ dữ liệu thư viện để bật tra cứu." : "Không hiển thị danh mục tác phẩm hoặc tài liệu giả. Kết nối nguồn dữ liệu có bản quyền và thông tin xuất bản để bật thư viện."}</p><span className="status-pill"><Database size={12} /> Đang chờ kết nối dữ liệu</span></section>
    <div className="muted-note" style={{ marginTop: 14 }}><BookOpenCheck size={14} style={{ verticalAlign: "middle", marginRight: 6 }} />Bạn có thể lưu câu hỏi và ghi chú nghiên cứu vào thư viện cá nhân mà không cần chờ nguồn tra cứu.</div>
  </div>
}
