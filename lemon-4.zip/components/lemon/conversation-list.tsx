"use client"

import Link from "next/link"
import { useState } from "react"
import { useRouter } from "next/navigation"
import { Clock3, MessageSquareText, Pencil, Trash2 } from "lucide-react"
import { createClient } from "@/lib/supabase/client"

type Conversation = { id: string; title: string; updated_at: string; created_at: string }

export function ConversationList({ initial }: { initial: Conversation[] }) {
  const [items, setItems] = useState(initial)
  const router = useRouter()

  async function rename(item: Conversation) {
    const title = window.prompt("Đổi tên cuộc trò chuyện", item.title)?.trim()
    if (!title || title === item.title || title.length > 120) return
    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) return
    const { error } = await supabase.from("conversations").update({ title, updated_at: new Date().toISOString() }).eq("id", item.id).eq("user_id", user.id)
    if (!error) setItems((current) => current.map((entry) => entry.id === item.id ? { ...entry, title } : entry))
  }

  async function remove(item: Conversation) {
    if (!window.confirm(`Xóa cuộc trò chuyện “${item.title}”?`)) return
    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) return
    const { error } = await supabase.from("conversations").delete().eq("id", item.id).eq("user_id", user.id)
    if (!error) setItems((current) => current.filter((entry) => entry.id !== item.id))
  }

  return <div>
    <div className="page-heading"><div><span className="page-kicker">LỊCH SỬ CÁ NHÂN</span><h1>Lịch sử trò chuyện</h1><p>Tin nhắn được lưu riêng theo tài khoản. Không có câu trả lời AI nào được tạo nếu chưa kết nối mô hình.</p></div><Link href="/chat" className="button button-primary button-small"><MessageSquareText size={15} /> Cuộc trò chuyện mới</Link></div>
    {items.length ? <div className="settings-list">{items.map((item) => <article className="settings-row" key={item.id}>
      <span className="settings-row-icon"><MessageSquareText size={17} /></span><div className="settings-row-copy"><strong>{item.title}</strong><small><Clock3 size={11} style={{ verticalAlign: "middle", marginRight: 4 }} />Cập nhật {new Intl.DateTimeFormat("vi-VN", { dateStyle: "medium" }).format(new Date(item.updated_at))}</small></div>
      <button className="small-action" type="button" onClick={() => void rename(item)} aria-label={`Đổi tên ${item.title}`}><Pencil size={13} /></button><button className="small-action danger" type="button" onClick={() => void remove(item)} aria-label={`Xóa ${item.title}`}><Trash2 size={13} /></button><Link className="small-action" href={`/chat?id=${item.id}`}>Mở</Link>
    </article>)}</div> : <section className="card-surface empty-state"><span className="empty-state-icon"><MessageSquareText size={19} /></span><strong>Chưa có lịch sử trò chuyện</strong><p>Bắt đầu một cuộc trò chuyện để lưu các câu hỏi của bạn trong không gian cá nhân.</p><Link href="/chat" className="subtle-link">Mở Chat với Lemon</Link></section>}
  </div>
}
