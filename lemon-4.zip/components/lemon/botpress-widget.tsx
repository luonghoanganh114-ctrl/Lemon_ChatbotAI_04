"use client"

import { useEffect, useState } from "react"
import { MessageCircle, X, ExternalLink } from "lucide-react"

export const BOTPRESS_URL = "https://cdn.botpress.cloud/webchat/v5.0/shareable.html?configUrl=https://files.bpcontent.cloud/2026/10/15/09/20261015090903-CUZWOLP1.json"

export function BotpressWidget() {
  const [open, setOpen] = useState(false)
  const [assessment, setAssessment] = useState<Record<string, unknown> | null>(null)

  useEffect(() => {
    const openChat = (event: Event) => {
      const detail = (event as CustomEvent<Record<string, unknown>>).detail ?? null
      setAssessment(detail)
      setOpen(true)
    }
    window.addEventListener("lemon:open-chat", openChat)
    return () => window.removeEventListener("lemon:open-chat", openChat)
  }, [])

  const chatbotUrl = assessment
    ? `${BOTPRESS_URL}#lemon_assessment=${encodeURIComponent(JSON.stringify(assessment))}`
    : BOTPRESS_URL

  return (
    <div className="botpress-dock">
      {open && (
        <section className="botpress-panel" aria-label="Chatbot LEMON">
          <header className="botpress-header">
            <div className="botpress-heading">
              <span className="botpress-status" />
              <div><strong>Trò chuyện cùng Lemon</strong><small>Trợ lý văn học · Botpress</small></div>
            </div>
            <div className="botpress-actions">
              <a className="botpress-icon-link" href={chatbotUrl} target="_blank" rel="noopener noreferrer" aria-label="Mở chatbot toàn màn hình"><ExternalLink size={17} /></a>
              <button className="botpress-icon-link" type="button" onClick={() => setOpen(false)} aria-label="Đóng chatbot"><X size={18} /></button>
            </div>
          </header>
          <iframe
            className="botpress-frame"
            src={chatbotUrl}
            title="Chatbot LEMON — Botpress"
            loading="lazy"
            referrerPolicy="strict-origin-when-cross-origin"
            onLoad={(event) => {
              if (assessment) event.currentTarget.contentWindow?.postMessage({ type: "lemon_assessment", payload: assessment }, "https://cdn.botpress.cloud")
            }}
          />
        </section>
      )}
      <button className={`botpress-launcher${open ? " is-open" : ""}`} type="button" onClick={() => setOpen((value) => !value)} aria-expanded={open} aria-label={open ? "Đóng chatbot Lemon" : "Mở chatbot Lemon"}>
        {open ? <X size={23} /> : <><MessageCircle size={23} /><span className="botpress-launcher-label">Hỏi Lemon</span></>}
      </button>
    </div>
  )
}
