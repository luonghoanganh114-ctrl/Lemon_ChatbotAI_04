import Link from "next/link"
import { ArrowRight, ArrowUpRight, BookMarked, BookOpenCheck, Clock3, FileText, GitCompareArrows, MessageSquareText, Scale, Sparkles, Users, type LucideIcon } from "lucide-react"

type SavedAnalysis = { id: string; title: string; work_title: string; author_name: string; analysis_mode: string; updated_at: string }
type Conversation = { id: string; title: string; updated_at: string }

const quickTools: { label: string; href: string; icon: LucideIcon }[] = [
  { label: "Phân tích tác phẩm", href: "/tools/analysis", icon: BookOpenCheck },
  { label: "Nghiên cứu tác giả", href: "/tools/author", icon: Users },
  { label: "So sánh văn học", href: "/tools/compare", icon: GitCompareArrows },
  { label: "Phản biện học thuật", href: "/tools/critique", icon: Scale },
  { label: "Kiểm chứng dẫn chứng", href: "/tools/verify", icon: FileText },
  { label: "Tra cứu kiến thức", href: "/library", icon: Sparkles },
]

function formatDate(value: string) {
  return new Intl.DateTimeFormat("vi-VN", { day: "2-digit", month: "short" }).format(new Date(value))
}

export function DashboardView({ name, analyses, conversations }: { name: string; analyses: SavedAnalysis[]; conversations: Conversation[] }) {
  const workCount = new Set(analyses.map((item) => item.work_title.trim().toLocaleLowerCase()).filter(Boolean)).size
  const metrics = [
    { label: "Bài phân tích đã lưu", value: analyses.length, icon: BookMarked },
    { label: "Cuộc trò chuyện", value: conversations.length, icon: MessageSquareText },
    { label: "Tác phẩm đã nghiên cứu", value: workCount, icon: BookOpenCheck },
    { label: "Hoạt động gần đây", value: analyses.length + conversations.length, icon: Clock3 },
  ]

  return (
    <div>
      <section className="dashboard-hero">
        <div className="dashboard-hero-copy">
          <span className="eyebrow-row"><Sparkles size={13} /> KHÔNG GIAN NGHIÊN CỨU CỦA BẠN</span>
          <h1>Xin chào, {name}.</h1>
          <p>Những ý tưởng hay xứng đáng được lưu lại. Tiếp tục khám phá chiều sâu của một tác phẩm, một tác giả hay một luận điểm.</p>
          <div className="dashboard-hero-actions">
            <Link href="/chat" className="button button-primary button-small">Mở Chat với Lemon <ArrowRight size={15} /></Link>
            <Link href="/tools/analysis" className="button button-quiet button-small">Bắt đầu nghiên cứu</Link>
          </div>
        </div>
        <div className="dashboard-hero-art" aria-hidden="true"><BookOpenCheck size={43} strokeWidth={1.5} /><span><Sparkles size={15} /></span></div>
      </section>

      <section className="metric-grid" aria-label="Thống kê từ dữ liệu cá nhân">
        {metrics.map(({ label, value, icon: Icon }) => <article className="metric-card" key={label}>
          <span className="metric-icon"><Icon size={18} /></span>
          <div><div className="metric-label">{label}</div><div className="metric-number">{value}</div></div>
        </article>)}
      </section>

      <div className="dashboard-grid">
        <div className="dashboard-column">
          <section className="dashboard-panel card-surface">
            <div className="card-heading"><div><h2>Khám phá công cụ nghiên cứu</h2><p>Chọn một lối vào cho câu hỏi tiếp theo.</p></div><span className="status-pill">Sẵn sàng tạo bản nháp</span></div>
            <div className="quick-tools">{quickTools.map(({ label, href, icon: Icon }) => <Link className="quick-tool" href={href} key={label}><span className="quick-tool-icon"><Icon size={17} /></span><span>{label}</span></Link>)}</div>
          </section>
          <section className="dashboard-panel card-surface">
            <div className="card-heading"><div><h2>Nghiên cứu gần đây</h2><p>Các bản phân tích đã lưu trong tài khoản của bạn.</p></div><Link href="/my-analyses" className="subtle-link">Xem thư viện <ArrowUpRight size={14} /></Link></div>
            {analyses.length ? <div className="recent-list">{analyses.slice(0, 4).map((item) => <Link className="recent-row" href={`/my-analyses/${item.id}`} key={item.id}><span className="recent-row-icon"><BookOpenCheck size={16} /></span><span className="recent-row-copy"><strong>{item.title}</strong><small>{item.work_title || "Chưa ghi tên tác phẩm"}{item.author_name ? ` · ${item.author_name}` : ""}</small></span><time dateTime={item.updated_at}>{formatDate(item.updated_at)}</time></Link>)}</div> : <div className="empty-state"><span className="empty-state-icon"><BookOpenCheck size={19} /></span><strong>Chưa có bài phân tích nào</strong><p>Bản nháp đầu tiên sẽ xuất hiện ở đây sau khi bạn lưu từ một công cụ nghiên cứu.</p><Link className="subtle-link" href="/tools/analysis">Tạo bản nháp đầu tiên <ArrowRight size={13} /></Link></div>}
          </section>
        </div>
        <div className="dashboard-column">
          <section className="dashboard-panel card-surface">
            <div className="card-heading"><div><h2>Trò chuyện gần đây</h2><p>Lịch sử riêng tư của tài khoản bạn.</p></div><Link href="/my-conversations" className="subtle-link">Tất cả <ArrowUpRight size={14} /></Link></div>
            {conversations.length ? <div className="recent-list">{conversations.slice(0, 3).map((item) => <Link className="recent-row" href={`/chat?id=${item.id}`} key={item.id}><span className="recent-row-icon"><MessageSquareText size={16} /></span><span className="recent-row-copy"><strong>{item.title}</strong><small>Cập nhật {formatDate(item.updated_at)}</small></span></Link>)}</div> : <div className="empty-state"><span className="empty-state-icon"><MessageSquareText size={19} /></span><strong>Chưa có cuộc trò chuyện</strong><p>Tạo cuộc trò chuyện mới để lưu lại câu hỏi nghiên cứu của bạn.</p><Link className="subtle-link" href="/chat">Mở Chat với Lemon <ArrowRight size={13} /></Link></div>}
          </section>
          <section className="dashboard-panel card-surface">
            <div className="card-heading"><div><h2>Gợi ý nghiên cứu</h2><p>Các câu hỏi mở để bạn bắt đầu.</p></div><span className="feature-icon green" style={{ width: 30, height: 30, marginBottom: 0 }}><Sparkles size={15} /></span></div>
            <div className="idea-list">
              <Link href="/tools/compare" className="idea-row"><span className="idea-index">01</span><span>Điều gì thay đổi khi đặt hai tác phẩm cùng thời cạnh nhau?</span><ArrowRight size={14} /></Link>
              <Link href="/tools/critique" className="idea-row"><span className="idea-index">02</span><span>Một cách diễn giải khác có thể làm lung lay luận điểm nào?</span><ArrowRight size={14} /></Link>
              <Link href="/tools/verify" className="idea-row"><span className="idea-index">03</span><span>Dẫn chứng này cần thêm nguồn nào để kiểm chứng?</span><ArrowRight size={14} /></Link>
            </div>
          </section>
          <div className="muted-note">Lemon chỉ lưu dữ liệu bạn chủ động tạo. Phân tích AI và kiểm chứng nguồn sẽ được bật khi dịch vụ tương ứng được kết nối.</div>
        </div>
      </div>
    </div>
  )
}
